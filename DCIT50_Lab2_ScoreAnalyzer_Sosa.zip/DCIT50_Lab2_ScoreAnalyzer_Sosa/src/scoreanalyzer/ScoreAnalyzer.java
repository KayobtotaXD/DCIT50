/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scoreanalyzer;

/**
 *
 * @author ICT B2-PC020
 */
public class ScoreAnalyzer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new GUI().setVisible(true);
    }
    
}
